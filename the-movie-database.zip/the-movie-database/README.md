# The Movie Database

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/XWoMObB/565b8a3b6df281d292667777a3492136](https://codepen.io/Nalini1998/pen/XWoMObB/565b8a3b6df281d292667777a3492136).

The Movie Database in React